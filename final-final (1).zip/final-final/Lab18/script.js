function submitForum() {
  alert ('Thank  you for coming')
}
//speling has to be the same from the index .YOU LEAD IN WITH LOWER CASE LETTER THE SEPERATE WORD HAS TO BE CAPITAL