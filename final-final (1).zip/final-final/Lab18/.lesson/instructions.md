# Instructions  

 1.  ** You have 25 minutes to edit the style.css file to make it look like the picture bellow**

  ![alt text](assets/Lab16CSS.png)
  
  _ DO NOT DELETE ANYTHING FROM THE HTML FILE _
  
  2.   ![alt text](assets/c1.png)
  3.   ![alt text](assets/c2.png)
  4. ![alt text](assets/c3.png)


