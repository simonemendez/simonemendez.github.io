# Instructions  

  ** Whack a mole **

 

  ![alt text](assets/1.png)
  
  