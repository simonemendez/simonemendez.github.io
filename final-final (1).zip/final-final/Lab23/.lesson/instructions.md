# Instructions  

  ** Make the Clock tick **

  

 
  ![alt text](assets/1.png)
  
  