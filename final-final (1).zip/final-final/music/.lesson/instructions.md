# Instructions  

  ** Make Music with your keyboard**

  ![alt text](assets/1.png)
  
   ![alt text](assets/2.png)
    ![alt text](assets/3.png)