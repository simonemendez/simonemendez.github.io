if(document.images){
	pic1=new Image();
	pic2=new Image();
	pic3=new Image();
	pic4=new Image();
	pic5=new Image();
	pic1.src='2.png';
	pic2.src='3.png';
	pic3.src='4.png';
	pic4.src='5.png';
	pic5.src='6.png';
}
else{
	pic1=pic2=pic3=pic4=pic5=document.r1="";
}