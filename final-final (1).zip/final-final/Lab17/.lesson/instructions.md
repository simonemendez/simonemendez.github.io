# Instructions  

  ** Use the HTML and Script bellow to create a page with 3 buttons that call on functions to display text as Pop Ups **

  _

 
  ![alt text](assets/Script.png)
  ![alt text](assets/PartialHTML.png)  
  