function goall1 ()
  {
    alert ('Mic check one two one two')
  }
function goal2 ()
  {
    alert ('Second goal is to be able to repeart it')
  }
function goal3 ()
  {
    alert ('third  goal is to annoy you with these alerts')
  }