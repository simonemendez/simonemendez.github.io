// Whatever the function is goingto do has to be inside the curly brackets ( did i do the function right on the index?)
// below is an example of a funtion you can do . the console log will only show up if you have the console page open.
// function doStuffFunc(){
  // console.log("Hello world, I'm doing some JS stuff!!")
}
for(i=0;i<4;i++){
  alert("Freeze Right There")
// doStuffFunc()  
}
//alet is a pop up that brings text outside thee page -- example of a sample output//
alert("this is an alert")
// if you keep adding the same code you will have to close the box more then once  //

// on the console for the developers benefit . the text in the quotes will pop up in the consle log//
console.log("this is due to a small debugging ")

// function--> then nameOfFuncrion( parameters which can be empty or a variable) then { . anything inside the curly bracket will be executed. See example  below
functon nameOfFunction{
  Alert("this is an alert")
}
//shays notes start here from class on june 22 ,2022//
// var - ( name , label, etc) var storage=“2” when you put things in quote it is not a number . it means nothing, it can be a " word, sentence, even a whole book” for example var storage=alert”hello”)  

// basic ways to create a variable
var storage ="string"// this containg alpha symbols

var storage1= 123 //contains number whole or decimal

var storage2= 5+9 // expresions any arithmetic calculation or logiic 
var storage2= true // this a boolean type of variable

var array=[ "list" ,"strings, "Booleans", names of other variables", " names of functions", " objects" , "numbers"]// this a list or array of thing one single memoray, they have an order called index which starts at 0 and counts by 1.
semicolon is old school java script and is option
a statement is a single  line of code

//output
alert(" this will be  pop up!")
document.write("this will re-write the html" doc")
console.log("this message will be only visible to developers")
document.writeln("<h5> this whill be html written inside the JS file</h5>""])
document.getElementsByTagName("body").innerHTML="write inside the selector/html element"
// top to bottom - left to right "https://replit.com/@qcc2022EDLc4
"
// do this inside the console
//example ++= by iteration is another word for change . i is the variable
var favoriteFoods=["Apple,Sushi,Banana"]
for(iteration=0; iteration<favoriteFoods.length; iteration++){console.log(favoriteFoods[i])
                                                             }
// the set up for loops//

// for (key in object{
 //the peice you want to repeat
} //
//
var bootCampLanguage=["html, "css" , "javascript"]//array or list 
//
var bootCamp{ week1"HTML", week2: "CSS", week 3:"JavaScript" // Object is a bucket only able to hold certain type of things} 
for (let x in Bootcamp){
  document.getElementbyId("forin").innnerHTML+bootCamp[x] + "<hr>"

  HTML<hr>CSS<hr>JavaScript <hr>
    //counter =variable hast o be defined before the loop and then increment inside the loop
    //while (condition){
    //code to be executed
    }
//example.
var countingVariable=0
             while(countingVariable<=10){ console.log("little piggy ")
                                         
